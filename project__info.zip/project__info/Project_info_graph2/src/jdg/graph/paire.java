package jdg.graph;
import jdg.graph.GridPoint_2;
import jdg.graph.*;
public class paire {
		  public Node e ;
		  public int n ;

		 
		  public paire(Node e,int n) { 
		  	this.e=e; 
		  	this.n=n;
		  }
	}

